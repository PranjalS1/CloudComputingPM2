from kafka import KafkaConsumer
consumer = KafkaConsumer('sample',api_version=(0,10,1),bootstrap_servers=['localhost:9093','localhost:9094','localhost:9095'],auto_offset_reset='earliest')
print("waiting...")
for message in consumer:
    print(message)