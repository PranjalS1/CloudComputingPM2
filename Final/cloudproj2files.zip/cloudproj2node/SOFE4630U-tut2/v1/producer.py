from kafka import KafkaProducer
from kafka.errors import KafkaError
print("start")
producer = KafkaProducer(bootstrap_servers=['SASL_SSL://pkc-v12gj.northamerica-northeast2.gcp.confluent.cloud:9092'],api_version=(0,10,1))
print("working")
producer.send('poems', b'Hello World2!')
print("sent")
producer.flush()
print("flushed")



